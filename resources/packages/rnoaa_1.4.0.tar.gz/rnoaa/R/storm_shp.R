#' storm shp files
#' @rdname storm_shp-defunct
#' @keywords internal
storm_shp <- function(...) .Defunct()

#' read storm shp files
#' @rdname storm_shp-defunct
#' @keywords internal
storm_shp_read <- function(...) .Defunct()
