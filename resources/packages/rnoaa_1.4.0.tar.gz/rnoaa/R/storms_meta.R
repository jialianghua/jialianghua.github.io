#' storm_meta
#' @export
#' @rdname storm_data-defunct
storm_meta <- function(...) .Defunct()
