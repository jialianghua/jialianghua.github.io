#' Get NOAA wind storm tabular data, metadata, or shp files from IBTrACS
#'
#' @export
#' @rdname storm_data-defunct
#' @keywords internal
storm_data <- function(...) .Defunct()
